---
## Front matter
lang: ru-RU
title: Отчёт выполнения лабораторной работы №4
author:
  - Архипов Александр Сегргеевич.
institute:
  - Российский университет дружбы народов, Москва, Россия

## i18n babel
babel-lang: russian
babel-otherlangs: english

## Formatting pdf
toc: false
toc-title: Содержание
slide_level: 2
aspectratio: 169
section-titles: true
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
---

# Информация

## Докладчик

:::::::::::::: {.columns align=center}
::: {.column width="70%"}

  * Рогозин Игорь Андреевич
  * студент группы НБИбд-03-23
  * Российский университет дружбы народов
  * [1132239106@pfur.ru](1132239106@pfur.ru)
  * <https://github.com/3ATOHIPOBAH>

:::
::: {.column width="30%"}

:::
::::::::::::::

# Вводная часть

## Цели и задачи

- Получение навыков правильной работы с репозиториями git.

## Материалы и методы

- Процессор `pandoc` для входного формата Markdown
- Результирующие форматы
	- `pdf`
	- `html`
- Автоматизация процесса создания: `Makefile`

# Выполнение лабораторной работы

##Установка git-flow

1. Установим git-flow

![рис. 1](image/1.png){#fig:001 width=70%}

##Установка Node.js

2. Установим Node.js

![рис. 2](image/2.png){#fig:001 width=70%}

##Настройка Node.js

3. Добавим каталог pnpm

![рис. 3](image/3.png){#fig:001 width=70%}

## Общепринятые коммиты

1. Установим commitizen

![рис. 4](image/4.png){#fig:001 width=70%}

2. Установим standard-changelog

![рис. 5](image/5.png){#fig:001 width=70%}

3. Используем то, что установили

1. Создадим какой-нибудь репозиторий

![рис. 6](image/6.png){#fig:001 width=70%}

2. Делаем коммит

3. Делаем конфигурацию пакетов Node.js

4. Редактируем файл package.json

![рис. 8](image/8.png){#fig:001 width=70%}

5. Отправляем всё на гитхаб

###3. Конфигурация git-flow

1. Загрузим git-flow

![рис. 9](image/9.png){#fig:001 width=70%}

2. Проверьте, что Вы на ветке develop

![рис. 10](image/10.png){#fig:001 width=70%}

3. Создадим журнал изменений

![рис. 11](image/11.png){#fig:001 width=70%}

4. Добавим журнал изменений в индекс

![рис. 12](image/12.png){#fig:001 width=70%}

5. Отправим данные на github

![рис. 13](image/13.png){#fig:001 width=70%}

##2. Работа с репозиторием git

1. Создадим ветку для новой функциональности

![рис. 14](image/14.png){#fig:001 width=70%}

###2. Создадим релиз git-flow

1. Создадим релиз с версией 1.2.3

2. Создадим журнал изменений

![рис. 15](image/15.png){#fig:001 width=70%}

3. Добавим журнал изменений

4. Отправим данные на github

![рис. 16](image/16.png){#fig:001 width=70%}


## Итоговый слайд

- Я научился пользоваться новыми функциями для работы с репозиториями github.

