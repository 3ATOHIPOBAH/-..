---
## Front matter
title: "Отчёт по лабораторной работе №6"
author: "Архипов Александр Сергеевич"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Ознакомление с файловой системой Linux, её структурой, именами и содержанием
каталогов. Приобретение практических навыков по применению команд для работы
с файлами и каталогами, по управлению процессами (и работами), по проверке использования диска и обслуживанию файловой системы.

# Выполнение лабораторной работы

##1. Выполните все примеры, приведённые в первой части описания лабораторной работы:

![рис. 1](image/1.png){#fig:001 width=70%}

##Выполним действия цифры 2

2.1. Скопируйте файл /usr/include/sys/io.h в домашний каталог и назовите его
equipment. Если файла io.h нет, то используйте любой другой файл в каталоге
/usr/include/sys/ вместо него:

![рис. 2](image/2.png){#fig:001 width=70%}

2.2. В домашнем каталоге создайте директорию ~/ski.plases:

![рис. 3](image/3.png){#fig:001 width=70%}

2.3. Переместите файл equipment в каталог ~/ski.plases:

![рис. 4](image/4.png){#fig:001 width=70%}

2.4. Переименуйте файл ~/ski.plases/equipment в ~/ski.plases/equiplist

![рис. 5](image/5.png){#fig:001 width=70%}

2.5. Создайте в домашнем каталоге файл abc1 и скопируйте его в каталог
~/ski.plases, назовите его equiplist2.:

![рис. 6](image/6.png){#fig:001 width=70%}

2.7. Переместите файлы ~/ski.plases/equiplist и equiplist2 в каталог
~/ski.plases/equipment.

![рис. 7](image/7.png){#fig:001 width=70%}

2.8. Создайте и переместите каталог ~/newdir в каталог ~/ski.plases и назовите
его plans.

![рис. 8](image/8.png){#fig:001 width=70%}

##Выполним действия под цифрой 4

4.1. Просмотрите содержимое файла /etc/password.

![рис. 9](image/9.png){#fig:001 width=70%}

4.2. Скопируйте файл ~/feathers в файл ~/file.old.

![рис. 10](image/10.png){#fig:001 width=70%}

4.3. Переместите файл ~/file.old в каталог ~/play.

![рис. 11](image/11.png){#fig:001 width=70%}

4.4. Скопируйте каталог ~/play в каталог ~/fun.

![рис. 12](image/12.png){#fig:001 width=70%}

4.5. Переместите каталог ~/fun в каталог ~/play и назовите его games.

![рис. 13](image/13.png){#fig:001 width=70%}

4.6. Лишите владельца файла ~/feathers права на чтение.

![рис. 14](image/14.png){#fig:001 width=70%}

4.7. Что произойдёт, если вы попытаетесь просмотреть файл ~/feathers командой
cat?

![рис. 15](image/15.png){#fig:001 width=70%}

4.8. Что произойдёт, если вы попытаетесь скопировать файл ~/feathers?

![рис. 16](image/16.png){#fig:001 width=70%}

4.9. Дайте владельцу файла ~/feathers право на чтение.

4.10. Лишите владельца каталога ~/play права на выполнение.

4.11. Перейдите в каталог ~/play. Что произошло?

Каталог недоступен

4.12. Дайте владельцу каталога ~/play право на выполнение.

5. Прочитайте man по командам mount, fsck, mkfs, kill и кратко их охарактеризуйте,
приведя примеры.
1. Mount - Подсоединение файловой системы
2. Fsck - Проверка и починка поврежденной файловой системы
3. Mkfs - Построить файловую систему в линуксе
4. Kill - Уничтожить процесс
![рис. 17](image/17.png){#fig:001 width=70%}

# Выводы

Я научился пользоваться новыми функциями для работы c Linux Fedora.

