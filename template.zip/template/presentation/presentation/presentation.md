---
## Front matter
lang: ru-RU
title: Отчёт выполнения лабораторной работы №4
author:
  - Архипов Александр Сергеевич.
institute:
  - Российский университет дружбы народов, Москва, Россия

## i18n babel
babel-lang: russian
babel-otherlangs: english

## Formatting pdf
toc: false
toc-title: Содержание
slide_level: 2
aspectratio: 169
section-titles: true
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
---

# Информация

## Докладчик

:::::::::::::: {.columns align=center}
::: {.column width="70%"}

  * Архипов Александр Сергеевич
  * студент группы НБИбд-03-23
  * Российский университет дружбы народов
  * [1132239106@pfur.ru](1132239106@pfur.ru)
  * <https://github.com/3ATOHIPOBAH>

:::
::: {.column width="30%"}

:::
::::::::::::::

# Вводная часть

## Цели и задачи

- Приобретение практических навыков взаимодействия пользователя с системой по-
средством командной строки.



# Выполнение лабораторной работы

##1. Выполните все примеры, приведённые в первой части описания лабораторной работы:

![рис. 1](image/1.png){#fig:001 width=70%}

##Выполним действия цифры 2

2.1. Скопируйте файл /usr/include/sys/io.h в домашний каталог и назовите его
equipment. Если файла io.h нет, то используйте любой другой файл в каталоге
/usr/include/sys/ вместо него:

![рис. 2](image/2.png){#fig:001 width=70%}

2.2. В домашнем каталоге создайте директорию ~/ski.plases:

![рис. 3](image/3.png){#fig:001 width=70%}

2.3. Переместите файл equipment в каталог ~/ski.plases:

![рис. 4](image/4.png){#fig:001 width=70%}

2.4. Переименуйте файл ~/ski.plases/equipment в ~/ski.plases/equiplist

![рис. 5](image/5.png){#fig:001 width=70%}

2.5. Создайте в домашнем каталоге файл abc1 и скопируйте его в каталог
~/ski.plases, назовите его equiplist2.:

![рис. 6](image/6.png){#fig:001 width=70%}

2.7. Переместите файлы ~/ski.plases/equiplist и equiplist2 в каталог
~/ski.plases/equipment.

![рис. 7](image/7.png){#fig:001 width=70%}

2.8. Создайте и переместите каталог ~/newdir в каталог ~/ski.plases и назовите
его plans.

![рис. 8](image/8.png){#fig:001 width=70%}

##Выполним действия под цифрой 4

4.1. Просмотрите содержимое файла /etc/password.

![рис. 9](image/9.png){#fig:001 width=70%}

4.2. Скопируйте файл ~/feathers в файл ~/file.old.

![рис. 10](image/10.png){#fig:001 width=70%}

4.3. Переместите файл ~/file.old в каталог ~/play.

![рис. 11](image/11.png){#fig:001 width=70%}

4.4. Скопируйте каталог ~/play в каталог ~/fun.

![рис. 12](image/12.png){#fig:001 width=70%}

4.5. Переместите каталог ~/fun в каталог ~/play и назовите его games.

![рис. 13](image/13.png){#fig:001 width=70%}

4.6. Лишите владельца файла ~/feathers права на чтение.

![рис. 14](image/14.png){#fig:001 width=70%}

4.7. Что произойдёт, если вы попытаетесь просмотреть файл ~/feathers командой
cat?

![рис. 15](image/15.png){#fig:001 width=70%}

4.8. Что произойдёт, если вы попытаетесь скопировать файл ~/feathers?

![рис. 16](image/16.png){#fig:001 width=70%}

4.9. Дайте владельцу файла ~/feathers право на чтение.

4.10. Лишите владельца каталога ~/play права на выполнение.

4.11. Перейдите в каталог ~/play. Что произошло?

Каталог недоступен

4.12. Дайте владельцу каталога ~/play право на выполнение.

5. Прочитайте man по командам mount, fsck, mkfs, kill и кратко их охарактеризуйте,
приведя примеры.
1. Mount - Подсоединение файловой системы
2. Fsck - Проверка и починка поврежденной файловой системы
3. Mkfs - Построить файловую систему в линуксе
4. Kill - Уничтожить процесс
![рис. 17](image/17.png){#fig:001 width=70%}


## Итоговый слайд

- Я научился пользоваться новыми функциями для работы c Linux Fedora.
